package com.frcoa.frcoaapi.rest;

import com.frcoa.frcoaapi.data.entities.InvTypeMaterials;
import com.frcoa.frcoaapi.data.entities.InvTypeMaterialsPK;
import com.frcoa.frcoaapi.data.entities.InvTypes;
import com.frcoa.frcoaapi.data.repositories.InvCategoriesRepository;
import com.frcoa.frcoaapi.data.repositories.InvGroupsRepository;
import com.frcoa.frcoaapi.data.repositories.InvTypesMaterialsRepository;
import com.frcoa.frcoaapi.data.repositories.InvTypesRepository;
import com.frcoa.frcoaapi.data.repositories.selector.SelectorInvTypesRepository;
import com.frcoa.frcoaapi.dto.*;
import com.frcoa.frcoaapi.dto.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Array;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value="/")
public class rootRessource {
    @Autowired
    private InvTypesRepository invTypesRepository;
    @Autowired
    private InvTypesDtoMapper invTypesDtoMapper;
    @Autowired
    private InvTypesSimpleDtoMapper invTypesSimpleDtoMapper;
    @Autowired
    private InvTypesMaterialsRepository invTypesMaterialsRepository;
    @Autowired
    private InvTypesProdDtoMapper invTypesProdDtoMapper;
    @Autowired
    private InvGroupsRepository invGroupsRepository;
    @Autowired
    private InvGroupsDtoMapper invGroupsDtoMapper;
    @Autowired
    private InvCategoriesRepository invCategoriesRepository;
    @Autowired
    private InvCategoriesDtoMapper invCategoriesDtoMapper;
    @Autowired
    private SelectorInvTypesRepository selectorInvTypesRepository;
    @RequestMapping(method = RequestMethod.GET)
    public List<InvTypesSimpleDto> getTypesSimple()
    {
        return invTypesSimpleDtoMapper.allToDtos(invTypesRepository.findAll());
    }

    @RequestMapping(value = "/raw",method = RequestMethod.GET)
    public List<InvTypes> getTypesRaw()
    {
        return invTypesRepository.findAll();
    }

    @RequestMapping(value = "/groups",method = RequestMethod.GET)
    public List<InvGroupsDto> getGroups()
    {
        return invGroupsDtoMapper.allToDtos(invGroupsRepository.findAll());
    }
    @RequestMapping(value = "/categories",method = RequestMethod.GET)
    public List<InvCategoriesDto> getCategories()
    {
        return invCategoriesDtoMapper.allToDtos(invCategoriesRepository.findAll());
    }
    @RequestMapping(params = {"groupid"}, method = RequestMethod.GET)
    public List<InvTypesSimpleDto> getTypesSimpleByGroupId(@RequestParam(required = true) Integer groupid)
    {
        return  invTypesSimpleDtoMapper.allToDtos(invTypesRepository.getInvTypesByGroupId(groupid));
    }
    @RequestMapping(params = {"categoryid"}, method = RequestMethod.GET)
    public List<InvTypesSimpleDto> getTypesSimpleByCategoriyId(@RequestParam(required = true) Integer categoryid)
    {
        return  invTypesSimpleDtoMapper.allToDtos(selectorInvTypesRepository.getByCategoryId(categoryid));
    }
    @RequestMapping(params = {"search"}, method = RequestMethod.GET)
    public List<InvTypesSimpleDto> getTypesSimpleBySearch(@RequestParam(required = true) String search)
    {
        return  invTypesSimpleDtoMapper.allToDtos(selectorInvTypesRepository.getBySearch(search));
    }
    @RequestMapping(value="/{typeId}", method= RequestMethod.GET)
    public InvTypesDto getOne(@PathVariable Integer typeId)
    {
        return invTypesDtoMapper.toDto(invTypesRepository.getInvTypesByTypeId(typeId));
    }

    @RequestMapping(value="/{typeId}/raw", method= RequestMethod.GET)
    public InvTypes getOneRaw(@PathVariable Integer typeId)
    {
        return invTypesRepository.getInvTypesByTypeId(typeId);
    }

    @RequestMapping(value="/{typeId}/prod", method= RequestMethod.GET)
    public InvTypesProdDto getOneProd(@PathVariable Integer typeId)
    {
        return invTypesProdDtoMapper.toDto(invTypesRepository.getInvTypesByTypeId(typeId));
    }

    private Map<String, Integer> retoursDivers;
    private Map<String, Integer> retoursBp;
    private Map<String, Integer> retourMaterials;
    private Map<String, Integer> retourComodity;
    private Map<String, Integer> retourPlanetaryComodity;
    private Map<String, Integer> retourCelestial;
    List<Map<String, Integer>> rtn;
    @RequestMapping(value="/{typeId}/prod/total", method= RequestMethod.GET)
    public List<Map<String, Integer>> getOneProdtotal2(@PathVariable Integer typeId)
    {
        InvTypesDto a_prod = invTypesDtoMapper.toDto(invTypesRepository.getInvTypesByTypeId(typeId));
        rtn = new ArrayList<>();
        parseProdByBP(a_prod, 0);
        return rtn;
    }
    public void parseProdByBP(InvTypesDto a_prod, Integer index)
    {
        Map<String, Integer> retour = new LinkedHashMap<>();
        rtn.add(index, retour);
        if(!a_prod.getBlueprints().isEmpty()) {
            if (!retour.containsKey(a_prod.getBlueprints().get(0).getBpType().getTypeName()))
                retour.put(a_prod.getBlueprints().get(0).getBpType().getTypeName(), a_prod.getBlueprints().get(0).getQuantity());
            else
                retour.put(a_prod.getBlueprints().get(0).getBpType().getTypeName(), retour.get(a_prod.getBlueprints().get(0).getBpType().getTypeName())+a_prod.getBlueprints().get(0).getQuantity());
            for (IndustryActivityMaterialsDto material : a_prod.getBlueprints().get(0).getIndustrialMaterials()) {
                switch (material.getMaterialProductType().getGroup().getCategoryId())
                {
                    default:
                        if(!retour.containsKey(material.getMaterialProductType().getTypeName()))
                            retour.put(material.getMaterialProductType().getTypeName()+" - "+material.getMaterialProductType().getGroup().getGroupName(), material.getQuantity());
                        else
                            retour.put(material.getMaterialProductType().getTypeName()+" - "+material.getMaterialProductType().getGroup().getGroupName(), retour.get(material.getMaterialProductType().getTypeName())+material.getQuantity());
                        break;
                }
                if(!material.getMaterialProductType().getBlueprints().isEmpty())
                    parseProdByBP(material.getMaterialProductType(),index+1);
            }
        }
    }
}
